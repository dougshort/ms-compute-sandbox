                        HEAT PatchLink Agent 8.3051
Supported Platforms
-------------------

   +------------------+-----------------+----------------+-------------+
   + Operating System + OS Version(s)   + OS Edition     + Minimum JRE +
   +==================+=================+================+=============+
   + Apple Mac OS X   + 10.9   -> 10.11 + All            + OpenJDK 7+  +
   +------------------+-----------------+----------------+-------------+
   + Apple macOS      + 10.12           + All            + OpenJDK 7+  +
   +------------------+-----------------+----------------+-------------+
   + IBM AIX          + 6.1    -> 7.1   + All            + JRE 7+      +
   +------------------+-----------------+----------------+-------------+
   + Red Hat          + 5.5    -> 7     + Server         + JRE 7+      +
   + Enterprise Linux +                 + Workstation    + OpenJDK 7+  +
   +------------------+-----------------+----------------+-------------+
   + SUSE             + 10 SP2 -> 12    + Server         + JRE 7+      +
   + Linux Enterprise +                 + Desktop        + OpenJDK 7+  +
   +------------------+-----------------+----------------+-------------+
   + Sun Solaris      + 10 U9  -> 11    + All            + JRE 7+      +
   +------------------+-----------------+----------------+-------------+
   + Oracle           + 5.5    -> 7     + All            + JRE 7+      +
   + Enterprise Linux +                 +                + OpenJDK 7+  +
   +------------------+-----------------+----------------+-------------+
   + Cent OS Linux    + 5.5    -> 7     + All            + JRE 7+      +
   +                  +                 +                + OpenJDK 7+  +
   +------------------+-----------------+----------------+-------------+
   + Ubuntu Linux     + 14.04 LTS       + Server         + JRE 7+      +
   +                  + 16.04 LTS       + Desktop        + OpenJDK 7+  +
   +------------------+-----------------+----------------+-------------+

System Requirements
-------------------

  * Superuser privileges to the target machine
  * Minimum 105 Mb free disk space for the agent installation
  * Network connectivity to a Update Server
  * Presence of /tmp directory (/var/tmp directory on Solaris) for temporary
    file storage and processing
  * Sufficient free disk space to download and install patches (varies per
    patch)

Installation Notes
------------------

   WARNING: The install (and uninstall) must to be done by the root user (the
            superuser)

1. Copy the UnixPatchAgent.tar file to the target machine
2. Untar UnixPatchAgent.tar using the following command:
       tar -xvf UnixPatchAgent.tar
3. The following eight files should be visible:
      * install
      * patchagent.tar
      * README.txt (this file)
      * patchagent.properties
4. For a MANUAL INSTALLATION, start the installation using the following
   command:
       ./install [-reinstall] [-user XXXX] [-detectonly]
   This method will:
      a. untar the patchagent.tar file to a new directory called patchagent
      b. Gather the installation settings, by prompting the user, prior to
        installing the Update Agent
5. For a SILENT INSTALLATION, start the installation using the following
   command:
       ./install -silent [-user XXXX] [-detectonly]
       -d <install directory> -p <HEAT EMSS Server address> -sno <serial number>
       [-proxy <proxy server address>
        -port <proxy port>
        -proxyuser <proxy user>
        -proxypassword <proxy password>
        -an <agent process nice value>
        -g <distinguished group names>]
   This method will:
      a. untar the patchagent.tar file to a new directory called patchagent
      b. Install the Update Agent using the provided settings
   If using the -g flag, the entire distinguished name must be entered.
     For example: OU=Test,OU=MY Groups
   If multiple groups are to be entered they must be seperated by a |.
     For example: OU=Test,OU=MY Groups | OU=Test2,OU=Test,OU=My Groups
   If your group name contains the ! character, please use the single
      quote around the group names.
   +------------------------+--------------------------------------------------+
   + Installation Modifier  + Purpose                                          +
   +========================+==================================================+
   + -user XXXX             + To make XXXX user the owner of the agent process +
   +------------------------+--------------------------------------------------+
   + -detectonly            + To prevent the agent from getting any tasks from +
   +                        + the Update Server                                +
   +------------------------+--------------------------------------------------+
   + -reinstall             + To reinstall the agent and use the agent id from +
   +                        + the previous installation                        +
   +------------------------+--------------------------------------------------+

6. To remove all patchagent related system files, invoke the following
   command. Invoking this command will make the current instance of
   the agent unusable. This command is only to be used if you intend
   to do a fresh agent install afterwards.
       ./install -cleanup

Managing the Agent
-------------------

The script patchservice (found in the patchagent directory) can be used to
manage and debug agent functionality
USAGE: patchservice <command>

   <command>      : Action Performed
   ==============================================================================
   info           : Information about the HEAT PatchLink Agent
   status         : Status of the HEAT PatchLink Agent process
   daustatus      : Status of the Discover Applicable Updates task
   detect         : Start the detection task
   start          : Start the HEAT PatchLink Agent process
   stop           : Stop the HEAT PatchLink Agent process
   restart        : Stop and start the HEAT PatchLink Agent process
   checknow       : To have the HEAT PatchLink Agent query the server for
                    pending tasks
   patchdirectory : To set the directory where patches will be temporarily
                    downloaded
   setmacro       : To specify the macro definition that should be used by the
                    agent
   trimlogs       : Trim the HEAT PatchLink Agent logs
   archivelogs    : Archive the HEAT PatchLink Agent logs so that they can be
                    sent to HEAT
   proxysetup     : Setup proxy server
   clearAgentLog  : Clear the HEAT PatchLink Agent log file
   clearErrLog    : Clear the HEAT PatchLink Agent error log file
   clearDetectLog : Clear the HEAT PatchLink Agent detection log file
   setagentnice   : To set the agent process nice value. An agent stop and
                    start is required
   help           : Display the patchservice script usage information

Uninstall Notes
---------------

1. Change your working directory to the patchagent directory created during the install
2. Uninstall the Update Agent using the following command:
       ./uninstall
   This will do the following:
      a. Un-register the agent from your Update Server
      b. Terminate the agent process
      c. Prompt the user to delete the patchagent directory

         WARNING: Deleting the patchagent directory will delete all of
                  Update Agent logs (stored under the patchagent/update/log).
                  If necessary, create a backup of the logs prior to deleting
                  the directory